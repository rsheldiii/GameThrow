require 'gameParser'
require 'game'

game = Game.create()

puts game
game.startingLineup
sleep(2)
game.stopClock
puts game
