class Player
  attr_reader :number, :name, :personalFouls, :technicalFouls, :freeThrows, :freeThrowAttempts, :threePointers, :threePointerAttempts, :twoPointers, :twoPointerAttempts, :time, :totalTime

  def to_s
    @name.to_s + ", " +  @number.to_s + ", " + @totalTime.to_s
  end

  def initialize(number,name)
    @freeThrows, @freeThrowAttempts,@personalFouls,@technicalFoulds,@threePointers,@threePointerAttempts, @twoPointers, @twoPointerAttempts, @totalTime = 0,0,0,0,0,0,0,0,0
    @name = name
    @number = number
  end

  #starttime should only be called first, or after endtime. no methods are exposed otherwise, and thus the functioning of the class relies on it
  def startTime()
    if @time != nil
      puts "ERROR: time in " + @number.to_s + " off, not adding"
    else
      @time = Time.now
    end
  end

  def stopTime()
    if @totalTime == nil
      puts "well theres your problem"
      @totalTime = 0
    end
    if @time != nil
      @totalTime += Time.now.to_i - @time.to_i
      puts (Time.now.to_i - @time.to_i).to_s
      @time = nil
    end
  end

  def madeFreeThrow()
    @freeThrowAttempts+=1
    @freeThrows+=1
  end
  
end


