class Parser


  def initialize(file)
    @keywordMap = {}
    f = File.open(file,'r')
    args = []
    while line = f.gets
      args.push(line)
    end
    
    args.each do |line|
      keyword = line.slice(/(.*)?=/,1)
      keymap = line.slice(/=(.*)/,1)
      case keyword
      when "shotAndMadeFreeThrow"
        @keywordMap["shotAndMadeFreeThrow"] = Regexp.new('\b'+keymap+'([0-9]{1,2})m\b')
      when "shotFreeThrow"
        @keywordMap["shotFreeThrow"] = Regexp.new('\b'+keymap+'([0-9]{1,2})\b')
      when "madeFreeThrow"
        @keywordMap["madeFreeThrow"] = Regexp.new('\b'+keymap+'\b')
      when "stopClock"
        @keywordMap["stopClock"] = Regexp.new('\b'+keymap+'\b')
      when "startClock"
        @keywordMap["startClock"] = Regexp.new('\b'+keymap+'\b')
      end
    end
  end

  def matchKeyword(line)
    @keywordMap.each { |function,regexp|
      if line =~ regexp
        return [function,line.slice(regexp,1)]
      end
      }
    return nil
  end
  
end
