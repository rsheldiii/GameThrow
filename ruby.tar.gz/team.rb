require 'player'

class Team
  attr_reader :teamRebounds, :turnOvers
  public
  def initialize(players)
    @teamRebounds, @turnOvers = 0
    @players = {}
    @playersOnCourt = []
      players.each do |player|
        @players[player.number] = player
      end
    self
  end


  def switchPlayer(goingIn, goingOut)
    self.addPlayer(goingIn)
    self.remPlayer(goingOut)
  end

  public
  def addPlayer(goingIn)
    @playersOnCourt.push(goingIn)
    goingIn.startTime()
  end

  def remPlayer(goingOut)
    @playersOnCourt.remove(goingOut)
    goingOut.stoptime()
  end

  def reset(numbers)
    puts numbers.length
    bool = true
    numbers.each do |number|
      if @players[number] == nil
        bool = false 
        puts number.to_s + "is not in there"
      end
    end
    puts bool
    if numbers.length == 5 and bool != false
      @playersOnCourt.each do |player|
        self.remPlayer(player)
      end
      @playersOnCourt = []
    
      numbers.each do |number|
        self.addPlayer(@players[number])
      end
      return true
    else puts "not 5 players, try again"
    return false
    end
  end
  
  def to_s
    out = ""
    @players.each do |number,player|

      out += player.to_s + "; "
    end
    return out[0,out.length-2]
  end

  def findPlayer(number)
    @players[number]
  end

  def stopClock()
    @playersOnCourt.each do |player|
      player.stopTime()
    end
  end

  def startClock()
    @playersOnCourt.each do |player|
      player.startTime()
    end
  end

  
end

