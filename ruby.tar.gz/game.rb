require 'gamestats'
require 'player'
require 'team'

class Game
  private_class_method :new
  def Game.create()
    puts "enter the name and numbers of the home team in pairs, ie '33,John Rogers,42,Michael Smith' etc without the quotes"
    hometeam = "22,lamar jones,23,h j williamson,12,Im gonna run out of names,45,penis flase,55,fart"#gets.chomp
    puts "now enter the away team"
    awayteam = "45,worthy worthington,56,anus,57,god I suck at dynamic memory,58,maybe thats why I do this shit,59,cock"#gets.chomp
    puts "where is the options file? relative path"
    optfile = "gamefunctions"#gets.chomp

    hteamplayerarr = []
    ateamplayerarr = []
    
    hteamarr = hometeam.scan(/[^,]+/).each_slice(2) {|b| hteamplayerarr.push(b)}
    ateamarr = awayteam.scan(/[^,]+/).each_slice(2) {|a| ateamplayerarr.push(a)} 
    puts hteamplayerarr
    
    hteamplayers = []
    ateamplayers = []

    hteamplayerarr.each {|arr| hteamplayers.push(Player.new(arr[0],arr[1]))}
    ateamplayerarr.each {|arr| ateamplayers.push(Player.new(arr[0],arr[1]))}

    
    parser = Parser.new(optfile)
    hometeam = Team.new(hteamplayers)
    awayteam = Team.new(ateamplayers)
    return new(hometeam,awayteam,parser)
  end
 
  def initialize(hometeam, awayteam, parser)
    @parser = parser
    @homeTeam = hometeam
    @awayTeam = awayteam
  end

  def to_s
    "Home team: " + @homeTeam.to_s + "\nAway team: " + @awayTeam.to_s
  end

  def startingLineup()
    begin
      puts "enter the starting lineup for the home team"
      temp = gets.chomp.scan(/[^,]+/)
      bool = @homeTeam.reset(temp)
    end while bool == false
    
    begin
      puts "enter the starting lineup for the away team"
      temp = gets.chomp.scan(/[^,]+/)	
      @awayTeam.reset(temp)
    end while bool == false
  end
  def stopClock()
    @homeTeam.stopClock
    @awayTeam.stopClock
  end
end 
